island_info: 
area, perimeter, and centroid X/Y info for each island

island_near_info:
nearest distance and number of neighbors within 100km for each island

island_near_info:
same as island_near_info but also contains mass effect as calculated within island_configuration script.

dbf:
folder containing dbf files of every island and information on nearest neighbors.
Used to calculate mass effect