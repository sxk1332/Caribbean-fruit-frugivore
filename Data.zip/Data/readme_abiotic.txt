Sources for abiotic data
Seokmin Kim

Koppen Geiger Climate Classification (KGCC)
http://www.gloh2o.org/koppen/

Precipitation: WorldClim 2.1 from http://worldclim.org
represents average monthly climate data for 1970-2000
Used Mosaic to New Raster tool in ArcGIS Pro to sum the monthly data to obtain average annual precipitation data.
Units: mm/year

Min_temp: WorldWorldClim 2.1 from http://worldclim.org
represents average monthly minimum temperature data for 1970-2000
Used Mosaic to New Raster tool in ArcGIS Pro to obtain the minimum temperature from a compilation of the monthly data to obtain average annual minimum temperature data.
Units: Degrees Celsius

Soil variety:
https://www.nrcs.usda.gov/wps/portal/nrcs/detail/soils/use/?cid=nrcs142p2_054013

 
