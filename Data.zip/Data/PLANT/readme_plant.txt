Sources for plant data
Seokmin Kim

full_plant_data retrieved from the Catalogue of Seed Plants of the West Indies
