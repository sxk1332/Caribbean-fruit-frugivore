Sources for biotic data
Seokmin Kim

compiled_bird_mass;compiled_bird_diversity;reptile_diversity_reptile_mass
Compiled accumulated and masses for reptiles and birds in raster format.

frugivore_data file includes the entire list of frugivorous animals in the Caribbean that we were able to find.
We only included mass information for native, frugivorous species.

bird species and REPTILES
raw information available from IUCN.

review_ref
references for materials used during the review
references for mammals not included